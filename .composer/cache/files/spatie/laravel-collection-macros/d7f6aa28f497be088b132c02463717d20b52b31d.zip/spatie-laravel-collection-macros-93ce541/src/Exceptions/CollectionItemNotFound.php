<?php

namespace Spatie\CollectionMacros\Exceptions;

use Exception;

class CollectionItemNotFound extends Exception
{
}
